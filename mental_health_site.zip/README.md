# Mental Health Support Website 🌿

**Get your Mental Str8** – Your journey to mental wellness starts here.

This website provides tools, resources, and merchandise to support mental health and wellness.

## 📁 Pages
- `index.html`: Home page with navigation to all sections
- `understanding.html`: Mental health basics
- `selfcare.html`: Self-care tips
- `professional-help.html`: Getting professional help
- `helping-others.html`: Supporting others
- `resources.html`: Emergency contacts and resources
- `shop.html`: Wellness shop

## 📬 Contact
📧 Email: [getyourmentalstr8@gmail.com](mailto:getyourmentalstr8@gmail.com)

## 📜 License
Code: MIT  
Content: CC BY-NC 4.0